<!-- ![logo](_media/pic.jpg) -->

# scikit-opt

> Powerful Python module for Heuristic Algorithms

* Genetic Algorithm
* Particle Swarm Optimization
* Simulated Annealing
* Ant Colony Algorithm
* Immune Algorithm
* Artificial Fish Swarm Algorithm

[GitHub](https://github.com/guofei9987/scikit-opt/)
[Get Started](/en/README)
